
package telas;


import javax.swing.JOptionPane;
import sistemavacinacao.Consulta;
import sistemavacinacao.ConsultasMarcadas;
import sistemavacinacao.Medico;
import sistemavacinacao.Paciente;
import static telas.TelaEnfermeira.nome;
import static telas.TelaEnfermeira.paciente;
import static telas.TelaEnfermeira.sus;


public class TelaMedico extends javax.swing.JFrame {
    TelaLogin objTela = new TelaLogin();
    public static Medico med;
    public static Paciente paciente;
    public static String nome;
    public static String sus;
   
    public TelaMedico() {
        initComponents();
        initatributo();
    }

    private void initatributo(){
    LabelNome.setText(med.getNome());
    LabelCrm.setText(med.getCRM()+"");
    LabelEspecialidade.setText(med.getEspecialidade());
    
    String resi;
    if (med.isResidente()== true){resi= "SIM";}
    else{ resi = "NÃO";}
    
    LabelResidente.setText(resi);
    if(nome== null){}
    else{
    Labelpaciente.setText(nome);}
   
   
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabelNomeM = new javax.swing.JLabel();
        LabelNome = new javax.swing.JLabel();
        jLabelResidenteM = new javax.swing.JLabel();
        LabelResidente = new javax.swing.JLabel();
        jLabelCrmM = new javax.swing.JLabel();
        LabelCrm = new javax.swing.JLabel();
        jLabelEspM = new javax.swing.JLabel();
        LabelEspecialidade = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Labelpaciente = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        BTNpacienteagendados = new javax.swing.JButton();
        BTNdadosdopaciente = new javax.swing.JButton();
        BTNprescrevervacina = new javax.swing.JButton();
        BTNfinalizaratendimento = new javax.swing.JButton();
        BTNencaminhar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema de vacinação");
        setBackground(new java.awt.Color(51, 153, 255));
        setPreferredSize(new java.awt.Dimension(6000, 281));
        setResizable(false);
        setSize(new java.awt.Dimension(600, 250));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel1.setText("Médico");

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel2.setText("Dados do médico");

        jLabelNomeM.setBackground(new java.awt.Color(255, 255, 255));
        jLabelNomeM.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabelNomeM.setText("Nome:");

        LabelNome.setBackground(new java.awt.Color(255, 255, 255));
        LabelNome.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabelResidenteM.setBackground(new java.awt.Color(255, 255, 255));
        jLabelResidenteM.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabelResidenteM.setText("Residente:");

        LabelResidente.setBackground(new java.awt.Color(255, 255, 255));
        LabelResidente.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabelCrmM.setBackground(new java.awt.Color(255, 255, 255));
        jLabelCrmM.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabelCrmM.setText("CRM:");

        LabelCrm.setBackground(new java.awt.Color(255, 255, 255));
        LabelCrm.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabelEspM.setBackground(new java.awt.Color(255, 255, 255));
        jLabelEspM.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabelEspM.setText("Especialidade:");

        LabelEspecialidade.setBackground(new java.awt.Color(255, 255, 255));
        LabelEspecialidade.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel3.setText("Paciente:");

        jButton6.setBackground(new java.awt.Color(255, 255, 255));
        jButton6.setText("LOGOFF");
        jButton6.setBorderPainted(true);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        BTNpacienteagendados.setBackground(new java.awt.Color(255, 255, 255));
        BTNpacienteagendados.setText("Pacientes agendados");
        BTNpacienteagendados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNpacienteagendadosActionPerformed(evt);
            }
        });

        BTNdadosdopaciente.setBackground(new java.awt.Color(255, 255, 255));
        BTNdadosdopaciente.setText("Dados do paciente");
        BTNdadosdopaciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNdadosdopacienteActionPerformed(evt);
            }
        });

        BTNprescrevervacina.setBackground(new java.awt.Color(255, 255, 255));
        BTNprescrevervacina.setText("Prescrever vacina");
        BTNprescrevervacina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNprescrevervacinaActionPerformed(evt);
            }
        });

        BTNfinalizaratendimento.setBackground(new java.awt.Color(255, 255, 255));
        BTNfinalizaratendimento.setText("Finalizar atendimento");
        BTNfinalizaratendimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNfinalizaratendimentoActionPerformed(evt);
            }
        });

        BTNencaminhar.setBackground(new java.awt.Color(255, 255, 255));
        BTNencaminhar.setText("Encaminhar");
        BTNencaminhar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNencaminharActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabelNomeM, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(LabelNome, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Labelpaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabelEspM)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(LabelEspecialidade, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(1, 1, 1)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabelResidenteM, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(LabelResidente, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabelCrmM, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(LabelCrm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                        .addGap(0, 27, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton6)
                        .addGap(61, 61, 61))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(178, 178, 178)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(BTNprescrevervacina, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(BTNpacienteagendados, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(BTNdadosdopaciente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(BTNencaminhar, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(67, 67, 67)
                                .addComponent(BTNfinalizaratendimento, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(jButton6))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelResidenteM, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelNomeM, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(LabelNome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(LabelResidente, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelEspM, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LabelEspecialidade, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelCrmM, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LabelCrm, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Labelpaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BTNpacienteagendados)
                    .addComponent(BTNdadosdopaciente))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BTNprescrevervacina)
                    .addComponent(BTNencaminhar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BTNfinalizaratendimento, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );

        setSize(new java.awt.Dimension(434, 390));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BTNfinalizaratendimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNfinalizaratendimentoActionPerformed
      try{
        new ConsultasMarcadas().atualizastatus(sus);
        nome="";
        sus="";
        JOptionPane.showMessageDialog(null, "Atendimento finalizado com sucesso!");
        dispose();
        new TelaMedico().setVisible(true);
      }
      catch (Exception excep){
                JOptionPane.showMessageDialog(null, "Você não possui paciente em atendimento, selecione antes de encerrar a consulta.", "Erro", JOptionPane.ERROR_MESSAGE);}
    
    }//GEN-LAST:event_BTNfinalizaratendimentoActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
     TelaLogin login= new TelaLogin();
        login.setVisible(true);
        
        dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void BTNencaminharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNencaminharActionPerformed
        try{long temp = Long.valueOf(sus);
        
        new Consulta().marcarconsultamedico(nome, temp);
        }catch(Exception e){JOptionPane.showMessageDialog(null, "Você não possui paciente em atendimento!");
        }
    }//GEN-LAST:event_BTNencaminharActionPerformed

    private void BTNdadosdopacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNdadosdopacienteActionPerformed
     try{
        Consulta obj= new Consulta();
       long temp= Long.valueOf(sus);
       obj.mostrarpaciente(nome, temp);
       }catch(Exception e){JOptionPane.showMessageDialog(null, "Não há nenhum paciente selecionado, por favor abra a tela de \"Pacientes agendados\" e selecione.");
       }
    }//GEN-LAST:event_BTNdadosdopacienteActionPerformed

    private void BTNpacienteagendadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNpacienteagendadosActionPerformed
     TeladeAgendados agendados= new TeladeAgendados();
        agendados.setVisible(true);
        dispose();

    }//GEN-LAST:event_BTNpacienteagendadosActionPerformed

    private void BTNprescrevervacinaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNprescrevervacinaActionPerformed
      med.prescrevervacinas(nome, sus);   
    }//GEN-LAST:event_BTNprescrevervacinaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaMedico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaMedico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaMedico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaMedico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaMedico().setVisible(true);
            }
        });
        
    }
     

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTNdadosdopaciente;
    private javax.swing.JButton BTNencaminhar;
    private javax.swing.JButton BTNfinalizaratendimento;
    private javax.swing.JButton BTNpacienteagendados;
    private javax.swing.JButton BTNprescrevervacina;
    private javax.swing.JLabel LabelCrm;
    private javax.swing.JLabel LabelEspecialidade;
    private javax.swing.JLabel LabelNome;
    private javax.swing.JLabel LabelResidente;
    private javax.swing.JLabel Labelpaciente;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabelCrmM;
    private javax.swing.JLabel jLabelEspM;
    private javax.swing.JLabel jLabelNomeM;
    private javax.swing.JLabel jLabelResidenteM;
    private javax.swing.JPopupMenu jPopupMenu1;
    // End of variables declaration//GEN-END:variables

   

}
