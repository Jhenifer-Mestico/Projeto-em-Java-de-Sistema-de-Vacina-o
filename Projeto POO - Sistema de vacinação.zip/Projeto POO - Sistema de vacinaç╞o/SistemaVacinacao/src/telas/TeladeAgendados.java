
package telas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.Timer;
import sistemavacinacao.ConsultasMarcadas;
import sistemavacinacao.Enfermeira;
import sistemavacinacao.Medico;

public class TeladeAgendados extends javax.swing.JFrame {
public static Enfermeira enfermeira;
public static Medico medico;
public static int id;
public static String tabela[][]=new String[40][9];


    public TeladeAgendados() {
        
        initComponents();
        inittabela();
        
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Jtabelaagendados = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuAjuda = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema de vacinação");
        setBackground(new java.awt.Color(204, 230, 230));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("PACIENTES AGENDADOS");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        Jtabelaagendados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "N° SUS", "NOME", "SINTOMAS", "DATA", "HORARIO", "MEDICO", "ENFERMEIRA", "MOTIVO", "STATUS"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        Jtabelaagendados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JtabelaagendadosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Jtabelaagendados);

        jLabel2.setText("Observação: Clicar no nome do paciente que deseja selecionar para atendimento.");

        jLabel3.setText("Clicar no motivo fará abrir uma janela detalhada.");

        jLabel4.setText("Finalize o atendimento ao encerrar consulta.");

        jButton1.setText("Voltar");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        jMenuAjuda.setText("Ajuda");
        jMenuAjuda.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuAjudaMouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenuAjuda);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(166, 166, 166)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel4)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(93, 93, 93)))))
                .addGap(174, 174, 174))
            .addGroup(layout.createSequentialGroup()
                .addGap(211, 211, 211)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(85, 85, 85)
                .addComponent(jButton1)
                .addGap(90, 90, 90))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGap(27, 27, 27)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void JtabelaagendadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JtabelaagendadosMouseClicked
        try{
                int a= Jtabelaagendados.getSelectedRow();
                 int b= Jtabelaagendados.getSelectedColumn();
                 String c = Jtabelaagendados.getColumnName(b);
                 String j=Jtabelaagendados.getValueAt(a, b).toString();
                 
                
                 if (c.equalsIgnoreCase("Nome")){
                   long k=Long.valueOf(Jtabelaagendados.getValueAt(a, (b-1)).toString());  
                   String v= Jtabelaagendados.getValueAt(a, (b+6)).toString();
                      if(id==0){
                          TelaMedico.nome=j;
                          TelaMedico.sus=k+"";
                          TelaMedico medico= new TelaMedico();
                          medico.setVisible(true);
                      
                      }
                        if (id==2){
                                TelaEnfermeira.nome=j;
                                TelaEnfermeira.sus=k+"";
                                TelaEnfermeira.vacina=v;
                                TelaEnfermeira enfermeira= new TelaEnfermeira();
                                enfermeira.setVisible(true);
                        
                        }
                     
                     dispose();
                 }
                 
                 else if(c.equalsIgnoreCase("Sintomas")){
                     JOptionPane meuJOPane = new JOptionPane(j);
                     final JDialog dialog = meuJOPane.createDialog(null,"");
                                                                   
                     dialog.setModal(true);  
       
                      Timer timer = new Timer(4 * 1000, new ActionListener() {  
                       public void actionPerformed(ActionEvent ev) { dialog.dispose();}});  
                        timer.start();
                        dialog.setVisible(true);
                        timer.stop();}
                 
                 else if(c.equalsIgnoreCase("Motivo")){
                     
                     JOptionPane meuJOPane = new JOptionPane(j);
                     final JDialog dialog = meuJOPane.createDialog(null,"");
                                                                   
                     dialog.setModal(true);  
       
                      Timer timer = new Timer(4 * 1000, new ActionListener() {  
                       public void actionPerformed(ActionEvent ev) { dialog.dispose();}});  
                        timer.start();
                        dialog.setVisible(true);
                        timer.stop();}}
       catch(Exception e){JOptionPane.showMessageDialog(null, "Não há nenhum paciente agendado!", "Aviso", JOptionPane.INFORMATION_MESSAGE);}
                 
    }//GEN-LAST:event_JtabelaagendadosMouseClicked

    private void jMenuAjudaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuAjudaMouseClicked
        JOptionPane.showMessageDialog(null, "Observação: Clicar no nome do paciente que deseja selecionar para atendimento.\nClicar no motivo ou sintomas fará abrir uma janela detalhada."
                + "\nFinalize o atendimento ao encerrar consulta.", "Ajuda", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_jMenuAjudaMouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
           if(id==0){
          TelaMedico medico= new TelaMedico();
          medico.setVisible(true);}
      
      if (id==2){
          TelaEnfermeira enfermeira= new TelaEnfermeira();
          enfermeira.setVisible(true);}
                     
         dispose();
    
    }//GEN-LAST:event_jButton1MouseClicked

    public static void main(String args[]) {
        
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TeladeAgendados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TeladeAgendados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TeladeAgendados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TeladeAgendados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TeladeAgendados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private static javax.swing.JTable Jtabelaagendados;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenuAjuda;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

    private void inittabela() {
            ConsultasMarcadas marcadas= new ConsultasMarcadas();
            String nome= null;
            int num= 0;
        
        if(id==0){nome= medico.getNome(); num=5;}
        if (id==2){nome= enfermeira.getNome();num=6;}
        marcadas.buscarmarcadastabela(nome);
         for (int i = 0; i < 40; i++) {
             for (int j = 0; j < 9; j++) {
                 
                 Jtabelaagendados.setValueAt(tabela[i][j], i, j);}}
        }

    }


