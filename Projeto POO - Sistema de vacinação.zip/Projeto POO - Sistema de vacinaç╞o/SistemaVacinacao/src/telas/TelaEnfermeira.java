
package telas;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import sistemavacinacao.Consulta;
import sistemavacinacao.ConsultasMarcadas;
import sistemavacinacao.Enfermeira;
import sistemavacinacao.Paciente;




public class TelaEnfermeira extends javax.swing.JFrame {
public static Enfermeira enfer;
public static Paciente paciente;
public static String nome;
public static String sus;
public static String vacina;
   
    public TelaEnfermeira() {
        initComponents();
        initatributo();
    }

     private void initatributo(){
         
    LabelNome.setText(enfer.getNome());
    LabelCorem.setText(enfer.getCoren()+"");
    if(nome== null){}
    else{
    LabelPaciente.setText(nome);}
    
    
    }
     
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        LabelNome = new javax.swing.JLabel();
        LabelCorem = new javax.swing.JLabel();
        BTNllogoff = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        LabelPaciente = new javax.swing.JLabel();
        BTNFinalizar = new javax.swing.JButton();
        BTNAgendados = new javax.swing.JButton();
        BTNencaminhar = new javax.swing.JButton();
        BTNaplicarvacina = new javax.swing.JButton();
        BTNDados = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema de vacinação");

        jLabel2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel2.setText("ENFERMEIRA");

        jLabel1.setText("Enfermeira:");

        jLabel3.setText("Corem:");

        BTNllogoff.setBackground(new java.awt.Color(255, 255, 255));
        BTNllogoff.setText("LOGOFF");
        BTNllogoff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNllogoffActionPerformed(evt);
            }
        });

        jLabel7.setText("Paciente:  ");

        BTNFinalizar.setBackground(new java.awt.Color(255, 255, 255));
        BTNFinalizar.setText("Finalizar Atendimento");
        BTNFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNFinalizarActionPerformed(evt);
            }
        });

        BTNAgendados.setBackground(new java.awt.Color(255, 255, 255));
        BTNAgendados.setText("Pacientes Agendados");
        BTNAgendados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNAgendadosActionPerformed(evt);
            }
        });

        BTNencaminhar.setBackground(new java.awt.Color(255, 255, 255));
        BTNencaminhar.setText("Encaminhar");
        BTNencaminhar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNencaminharActionPerformed(evt);
            }
        });

        BTNaplicarvacina.setBackground(new java.awt.Color(255, 255, 255));
        BTNaplicarvacina.setText("Aplicar Vacina");
        BTNaplicarvacina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNaplicarvacinaActionPerformed(evt);
            }
        });

        BTNDados.setBackground(new java.awt.Color(255, 255, 255));
        BTNDados.setText("Dados do Paciente");
        BTNDados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNDadosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(LabelPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(LabelNome, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(LabelCorem, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(122, 122, 122)))
                        .addComponent(BTNllogoff))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(BTNaplicarvacina, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(BTNAgendados, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE))
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BTNDados, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BTNencaminhar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(52, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(128, 128, 128)
                        .addComponent(BTNFinalizar, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(153, 153, 153)
                        .addComponent(jLabel2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(BTNllogoff)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelNome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelCorem, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LabelPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(19, 19, 19)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BTNAgendados)
                    .addComponent(BTNDados))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BTNaplicarvacina)
                    .addComponent(BTNencaminhar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(BTNFinalizar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BTNllogoffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNllogoffActionPerformed
        TelaLogin login= new TelaLogin();
        login.setVisible(true);
        
        dispose();
    }//GEN-LAST:event_BTNllogoffActionPerformed

    private void BTNencaminharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNencaminharActionPerformed
        try{long temp = Long.valueOf(sus);
        
        new Consulta().marcarconsultamedico(nome, temp);
        }catch(Exception e){JOptionPane.showMessageDialog(null, "Você não possui paciente em atendimento!");
        }
    }//GEN-LAST:event_BTNencaminharActionPerformed

    private void BTNAgendadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNAgendadosActionPerformed
            TeladeAgendados agendados= new TeladeAgendados();
            agendados.setVisible(true);
            dispose();
    }//GEN-LAST:event_BTNAgendadosActionPerformed

    private void BTNFinalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNFinalizarActionPerformed
      try{
        new ConsultasMarcadas().atualizastatus(sus);
      nome="";
      sus="";
      JOptionPane.showMessageDialog(null, "Atendimento finalizado com sucesso!");
      dispose();
      new TelaEnfermeira().setVisible(true); 
      }catch (Exception excep){
                JOptionPane.showMessageDialog(null, "Você não possui paciente em atendimento, selecione antes de encerrar a consulta.", "Erro", JOptionPane.ERROR_MESSAGE);}
    }//GEN-LAST:event_BTNFinalizarActionPerformed

    private void BTNDadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNDadosActionPerformed
       try{
      Consulta obj= new Consulta();
       long temp= Long.valueOf(sus);
       obj.mostrarpaciente(nome, temp);  
       }catch(Exception e){JOptionPane.showMessageDialog(null, "Não há nenhum paciente selecionado, por favor abra a tela de \"Pacientes agendados\" e selecione.");
       }
    }//GEN-LAST:event_BTNDadosActionPerformed

    private void BTNaplicarvacinaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNaplicarvacinaActionPerformed
    try{
        int idade=new Consulta().BuscarIdade(nome, sus);
        double dose= new Consulta().pegardose(vacina, idade);
        enfer.aplicarVacinas(LabelNome.getText(), nome, vacina, dose);
   
    }catch(Exception e){JOptionPane.showMessageDialog(null, "Selecione o paciente antes de realizar esta ação!");}           
        
        
    }//GEN-LAST:event_BTNaplicarvacinaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaEnfermeira.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaEnfermeira.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaEnfermeira.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaEnfermeira.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaEnfermeira().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTNAgendados;
    private javax.swing.JButton BTNDados;
    private javax.swing.JButton BTNFinalizar;
    private javax.swing.JButton BTNaplicarvacina;
    private javax.swing.JButton BTNencaminhar;
    private javax.swing.JButton BTNllogoff;
    private javax.swing.JLabel LabelCorem;
    private javax.swing.JLabel LabelNome;
    private javax.swing.JLabel LabelPaciente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    // End of variables declaration//GEN-END:variables
}
