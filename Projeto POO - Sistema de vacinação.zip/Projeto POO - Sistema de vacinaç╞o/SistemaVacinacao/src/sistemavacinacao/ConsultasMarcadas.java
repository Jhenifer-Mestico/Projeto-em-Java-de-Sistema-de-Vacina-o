
package sistemavacinacao;

import java.awt.Color;
import java.awt.TextArea;
import javax.swing.JOptionPane;
import static telas.TeladeAgendados.tabela;


public class ConsultasMarcadas{
    
    private String horario,medico, enfermeira, sintomas, motivo,status;
    private Data date;
    private static ConsultasMarcadas consultas[];
    private static int x;
    private long sus ;

    public ConsultasMarcadas() {
    }

    public ConsultasMarcadas(long sus, String horario, String medico, String enfermeira, String sintomas, Data date, String motivo,String status) {
        this.sus = sus;
        this.horario = horario;
        this.medico = medico;
        this.enfermeira = enfermeira;
        this.sintomas = sintomas;
        this.date = date;
        this.motivo= motivo;
        this.status= status;
        
    }

    public static ConsultasMarcadas[] getConsultas() {
        return consultas;
    }

    public static void setConsultas(ConsultasMarcadas[] consultas) {
        ConsultasMarcadas.consultas = consultas;
    }

    public long getSus() {
        return sus;
    }

    public void setSus(long sus) {
        this.sus = sus;
    }


    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getMedico() {
        return medico;
    }

    public void setMedico(String medico) {
        this.medico = medico;
    }

    public String getEnfermeira() {
        return enfermeira;
    }

    public void setEnfermeira(String enfermeira) {
        this.enfermeira = enfermeira;
    }

    public String getSintomas() {
        return sintomas;
    }

    public void setSintomas(String sintomas) {
        this.sintomas = sintomas;
    }

    public Data getDate() {
        return date;
    }

    public void setDate(Data date) {
        this.date = date;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    
    
  public void salvardadosconsulta(ConsultasMarcadas cm){
  
        if (consultas == null){
        Atualizar();
        consultas= new ConsultasMarcadas[x];
        consultas[0]= cm;}
        
        else{
            ConsultasMarcadas aux[]= new ConsultasMarcadas[consultas.length];
    
            for(int i=0;i<aux.length; i++){
            aux[i]= consultas[i];}

            Atualizar();
            consultas= new ConsultasMarcadas[x];
            consultas[x-1]= cm;

            for(int i=0; i<x-1;i++){
            consultas[i]=aux[i];}
        }}

    private void Atualizar() {
    x++;}

    public void  Buscarconsultapaciente( long sus){
        int p=0;
       try{
        
        for (int i=0;i<consultas.length;i++){
            long s=consultas[i].getSus();
            if (s==sus){
                p++;}}
           
    if (p>0){    
   
    ConsultasMarcadas[] tmp= new ConsultasMarcadas[1];
    
    for (int i = 0; i < consultas.length - 1; i++) {
        for (int j = 0; j < consultas.length - 1-i; j++) {
            if (consultas[j].getDate().getAno()>= consultas[j+1].getDate().getAno()) {
                if (consultas[j].getDate().getMes()>=consultas[j+1].getDate().getMes()) {
            if (consultas[j].getDate().getDia() >=consultas[j+1].getDate().getDia()) {
            tmp[0] = consultas[j];
            consultas[j] = consultas[j+1];
            consultas[j+1] = tmp[0];
            }
                   
        
        }}}}
        TextArea text = new TextArea();
              text.setText("Você possui "+consultas.length+ /*p*/ " consulta(s) marcada(s).\nA próxima é em  " + consultas[0].getDate().toString()+
                       " às "+consultas[0].getHorario().toString()+".\nO(a) Doutor(a) "+consultas[0].getMedico().toString()+ 
                       " e a Enfermeira "+ consultas[0].getEnfermeira().toString()+", irão te atender.\nNão se atrase! Chegue com 10 minutos de antecedência.");
    
    JOptionPane show = new JOptionPane();
    show.showMessageDialog(null, text, "Consultas marcadas", JOptionPane.INFORMATION_MESSAGE);

    
    }
    
    else{JOptionPane.showMessageDialog(null, "Não há registro de consultas agendadas para seu número SUS!\nRealize um novo agendamento na tela \"Marcar consulta\"", "Consultas", JOptionPane.INFORMATION_MESSAGE);}
      
    }
    catch(Exception e ){JOptionPane.showMessageDialog(null, "Não há registro de consultas agendadas para seu número SUS!\nRealize um novo agendamento no botão \"Marcar consulta\"", "Consultas", JOptionPane.INFORMATION_MESSAGE);}
   
    
    }

    
    public String buscarmarcadastabela(String nome){
       try{
        int p=0;
    
            for (int i=0;i<consultas.length;i++){
             if (nome.equals(consultas[i].getEnfermeira()) || nome.equals(consultas[i].getMedico())){
             Consulta consulta= new Consulta();
             
            String nomepaciente =consulta.bruscarnome(consultas[i].getSus());
             
            telas.TeladeAgendados.tabela[p][0]= (consultas[i].getSus())+"";
            telas.TeladeAgendados.tabela[p][1]= nomepaciente;
            telas.TeladeAgendados.tabela[p][2]= (consultas[i].getSintomas());
            telas.TeladeAgendados.tabela[p][3]= (consultas[i].getDate().toString());
            telas.TeladeAgendados.tabela[p][4]= (consultas[i].getHorario());
            telas.TeladeAgendados.tabela[p][5]= (consultas[i].getMedico());
            telas.TeladeAgendados.tabela[p][6]= (consultas[i].getEnfermeira());
            telas.TeladeAgendados.tabela[p][7]= (consultas[i].getMotivo());
            telas.TeladeAgendados.tabela[p][8]= (consultas[i].getStatus());
            p++;
    }}
       }
       catch(Exception e){JOptionPane.showMessageDialog(null, "Não há consultas agendadas!", "Aviso", JOptionPane.INFORMATION_MESSAGE);}
    
   
    
    
    
    return "Carregado com sucesso!";



}
        
    public void atualizastatus(String sus){
        long temp=Long.valueOf(sus);
        for (int i =0;i<consultas.length; i++){
            if(consultas[i].getStatus().equalsIgnoreCase("Atendido")){}
            else if(consultas[i].getSus()== temp){
            consultas[i].setStatus("Atendido");
            break;}}
    }
        
        }
    
    

