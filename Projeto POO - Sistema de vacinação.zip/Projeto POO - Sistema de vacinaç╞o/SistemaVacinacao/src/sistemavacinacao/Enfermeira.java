
package sistemavacinacao;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import static telas.TelaEnfermeira.nome;
import static telas.TelaEnfermeira.vacina;

public class Enfermeira extends Pessoa {
    private int coren;

    public Enfermeira() {
    }

    public Enfermeira(int coren) {
        this.coren = coren;
    }

    public int getCoren() {
        return coren;
    }

    public void setCoren(int coren) {
        this.coren = coren;
    }
    public void aplicarVacinas(String enfermeira, String nome, String vacina, double dose){
      DecimalFormat form= new DecimalFormat("0.00");
    
        JTextArea texto= new JTextArea();
        texto.setText(enfermeira +", de acordo com a idade do paciente "+ nome + ", recomenda-se a aplicação da "+ vacina
            +" com a dose de "+ form.format(dose)+"ml.\n\n\t\tConfirme ou cancele a aplicação.");
        
   JOptionPane.showConfirmDialog(null, texto, "Aplicar vacina", JOptionPane.INFORMATION_MESSAGE);
        
        
    }
    
    
    public void extendes(String nome, int idade, String cpf, String email, String login, String senha, Endereco end){
        setNome(nome);
        setIdade(idade);
        setCpf(cpf);
        setEmail(email);
        setLogin(login);
        setSenha(senha);
        setEndereco(end);
    
    
    }
}
    
