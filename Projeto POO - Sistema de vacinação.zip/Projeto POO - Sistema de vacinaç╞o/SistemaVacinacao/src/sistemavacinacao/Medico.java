
package sistemavacinacao;

import javax.swing.JOptionPane;
import static telas.TelaMedico.nome;
import static telas.TelaMedico.sus;
import telas.TelaPrescreverVacina;


public class Medico extends Pessoa {
    private int CRM;
    private String especialidade;
    private boolean residente;

    public Medico() {
    }

    public Medico(int CRM, String especialidade, boolean residente) {
        this.CRM = CRM;
        this.especialidade = especialidade;
        this.residente = residente;
    }

    public int getCRM() {
        return CRM;
    }

    public void setCRM(int CRM) {
        this.CRM = CRM;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public boolean isResidente() {
        return residente;
    }

    public void setResidente(boolean residente) {
        this.residente = residente;
    }
    
    public void prescrevervacinas(String nome, String sus){
       TelaPrescreverVacina.nome=nome;
       TelaPrescreverVacina.sus=sus;
       
       new TelaPrescreverVacina().setVisible(true);
        
    }
    
    public void extendes(String nome, int idade, String cpf, String email, String login, String senha, Endereco end){
        setNome(nome);
        setIdade(idade);
        setCpf(cpf);
        setEmail(email);
        setLogin(login);
        setSenha(senha);
        setEndereco(end);
    }

    @Override
    public String toString() {
        return "Medico{" + "CRM=" + CRM + ", especialidade=" + especialidade + ", residente=" + residente + '}';
    }
   
   
   
}
