
package sistemavacinacao;

import javax.swing.JOptionPane;

public class Paciente extends Pessoa{
    private String cartaoDeAgendamento;
    private long cartaoDoSus;

    public Paciente() {
    }

    public Paciente(String cartaoDeAgendamento, long cartaoDoSus) {
        this.cartaoDeAgendamento = cartaoDeAgendamento;
        this.cartaoDoSus = cartaoDoSus;
    }

    public String getCartaoDeAgendamento() {
        return cartaoDeAgendamento;
    }

    public void setCartaoDeAgendamento(String cartaoDeAgendamento) {
        this.cartaoDeAgendamento = cartaoDeAgendamento;
    }

    public long getCartaoDoSus() {
        return cartaoDoSus;
    }

    public void setCartaoDoSus(long cartaoDoSus) {
        this.cartaoDoSus = cartaoDoSus;
    }

   public void extendes(String nome, int idade, String cpf, String email, String login, String senha, Endereco end){
        setNome(nome);
        setIdade(idade);
        setCpf(cpf);
        setEmail(email);
        setLogin(login);
        setSenha(senha);
        setEndereco(end);}
   
}
