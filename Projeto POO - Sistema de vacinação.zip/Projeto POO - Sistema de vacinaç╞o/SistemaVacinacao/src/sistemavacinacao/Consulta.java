package sistemavacinacao;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import telas.TelaLogin;
import telas.TelaMarcarConsulta;
import telas.TelaDadosPacientes;



public class Consulta{
    private static Medico medico[];
    private static Enfermeira enfermeira[];
    private static Paciente paciente[];
    private static  ArrayList <Vacina> vacina;
    private Data data;
    
 
    private static int m,e,p;
    
    public Consulta() {
        
    }
    public ArrayList getVacina() {
        return vacina;
    }

    public void setVacina(ArrayList vacina) {
        this.vacina = vacina;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }
    
   
    public void mostrarpaciente( String nome, long sus  ){
    try{
        if(nome.equals("") && sus == 0)
            
            {
         throw new Exception();}
         
         else{
    for(int i=0; i<paciente.length;i++){
    if(nome.equals(paciente[i].getNome())){
    if (sus==paciente[i].getCartaoDoSus()){
    telas.TelaDadosPacientes.paciente=paciente[i];
    
    TelaDadosPacientes obj = new TelaDadosPacientes();
    obj.setVisible(true);
    
     }}}}}
    catch(Exception e){JOptionPane.showMessageDialog(null, "Você não possui paciente em atendimento!");}}
    
    
    
    private void Atualizar(int n){
        if (n==0){p++;}
        else if(n==1){m++;}
        else if (n==2){e++;}
        }
    
    public void SalvarDados( int n,Pessoa dados){
    if(n==0){ 
        if (paciente == null){
        Atualizar(n);
        paciente= new Paciente[p];
        paciente[0]= (Paciente) dados;}
        
        else{
            Paciente aux[]= new Paciente[paciente.length];
    
            for(int i=0;i<aux.length; i++){
            aux[i]= paciente[i];}

            Atualizar(n);
            paciente= new Paciente[p];
            paciente[p-1]= (Paciente) dados;

            for(int i=0; i<p-1;i++){
            paciente[i]=aux[i];}
        }}
    
}

    public int Login(String login, String senha){

     int resp= -1;
     
     
     if (resp<0) {
     for (int i=0; i<medico.length;i++){
     if(medico[i].getLogin().equals(login)){resp=-2;
         if(medico[i].getSenha().equals(senha)){
         resp=1;telas.TelaMedico.med=medico[i];
         telas.TeladeAgendados.medico=medico[i];
         telas.TeladeAgendados.id=0;
         }}}}
     
    if (resp<0) {
     for (int i=0; i<enfermeira.length;i++){
         if(enfermeira[i].getLogin().equals(login)){resp=-2;
         if(enfermeira[i].getSenha().equals(senha)){
         resp=2;telas.TelaEnfermeira.enfer=enfermeira[i];
         telas.TeladeAgendados.enfermeira=enfermeira[i];
         telas.TeladeAgendados.id=2;
         }}}}
    
    
     if (paciente==null) {}
     else{
      if (resp<0) {
     for (int i=0; i<paciente.length;i++){
     if(paciente[i].getLogin().equals(login)){resp=-2;
         if(paciente[i].getSenha().equals(senha)){
         resp=0;telas.TelaUsuario.paciente=paciente[i];
         }}}}}
     
     if (resp==-1){resp=3;}

     return resp;
     
 
 }
 
    public void simuladadosmedico(){
        Consulta cons= new Consulta();
        medico= new Medico[4];
        enfermeira=new Enfermeira[3];
        vacina= new ArrayList<>();
        
        medico[0]= new Medico(12345, "Clínico Geral", true);
        medico[0].extendes("Bruna", 35, "055.548.879-98", "bruninhagatinhastiles@gmail.com", "12345", "bruna45",new Endereco("rua", "Machado de Assis", 1544, "sao petrusquio", "São Paulo", "SP", "02689-890"));
        
        medico[1]= new Medico(67891, "Clínico Geral", false);
        medico[1].extendes("Jhenifer", 45, "458.448.444-89", "Jheni2021@gmail.com", "67891", "jhenifer91",new Endereco("rua", "Nova Alvorada", 6947, "sao roque", "São Paulo", "SP", "05879-455"));
        
        medico[2]= new Medico(23456, "Neurocirurgiado", true);
        medico[2].extendes("Emesson", 33, "254.458.879-89", "emesson1514@gmail.com", "23456", "",new Endereco("rua", "alvaro de lins", 6547, "pq santo antonio", "São Paulo", "SP", "78985-582"));
   
        medico[3]= new Medico(78912, "Psiquiatra", false);
        medico[3].extendes("Gabrielly", 29, "144.458.877.01", "Gaby2020@outlook.com", "78912", "1",new Endereco("rua", "Santos Lourenzo", 8574, "pq do retorno", "São Paulo", "SP", "67895-98"));
   
      
        
        enfermeira[0]= new Enfermeira(15454);
        enfermeira[0].extendes("Marta", 32, "455.454.987-78", "Martinha1415@gmail.com", "15454", "marta54", new Endereco("rua", "Caxias", 54, "sao joão", "São Paulo", "sp", "45698-554"));
    
        enfermeira[1]= new Enfermeira(52473);
        enfermeira[1].extendes("Joana", 40, "578.567.898-98", "jo101015@gmail.com", "52473", "joana73", new Endereco("rua", "lamparinas", 454, "pq dos campos", "São Paulo", "sp", "55454-000"));
    
        enfermeira[2]= new Enfermeira(12456);
        enfermeira[2].extendes("Maria", 48, "787.789.977-00", "Mary5489@gmail.com", "12456", "maria56", new Endereco("rua", "Luciana Pacheco", 324, "pq campos elisa", "São Paulo", "sp", "45698-554"));
    
     
        
        vacina.add(new Vacina("vacina sarampo", 0.40, "0 - 2 anos", new Data(01, 05, 2025)));
        vacina.add(new Vacina("vacina sarampo", 0.60, "3  – 9 anos", new Data(01, 05, 2025)));
        vacina.add(new Vacina("vacina sarampo", 0.80, "10 - 18 anos", new Data(01, 05, 2025)));
        vacina.add(new Vacina("vacina sarampo", 1.00, "Acima de 18 anos", new Data(01, 05, 2025)));
        vacina.add(new Vacina("vacina h1n1", 0.30, "0 - 2 anos", new Data(01, 05, 2022)));
        vacina.add(new Vacina("vacina h1n1", 0.60, "3  – 9 anos", new Data(01, 05, 2022)));
        vacina.add(new Vacina("vacina h1n1", 0.90, "10 - 18 anos", new Data(01, 05, 2022)));
        vacina.add(new Vacina("vacina h1n1", 1.20, "Acima de 18 anos", new Data(01, 05, 2022)));
        vacina.add(new Vacina("vacina meningite", 0.10, "0 - 2 anos", new Data(24, 03, 2024)));
        vacina.add(new Vacina("vacina meningite", 0.40, "3  – 9 anos", new Data(24, 03, 2024)));
        vacina.add(new Vacina("vacina meningite", 0.60, "10 - 18 anos", new Data(24, 03, 2024)));
        vacina.add(new Vacina("vacina meningite", 0.90, "Acima de 18 anos", new Data(24, 03, 2024)));
        vacina.add(new Vacina("vacina malária", 0.25, "0 - 2 anos", new Data(15, 12, 2030)));
        vacina.add(new Vacina("vacina malária", 0.35, "3  – 9 anos", new Data(15, 12, 2030)));
        vacina.add(new Vacina("vacina malária", 0.75, "10 - 18 anos", new Data(15, 12, 2030)));
        vacina.add(new Vacina("vacina malária", 0.80, "Acima de 18 anos", new Data(15, 12, 2030)));
        vacina.add(new Vacina("Vacina covid19", 0.20, "0 - 2 anos", new Data(29, 11, 2025)));
        vacina.add(new Vacina("Vacina covid19", 0.55, "3  – 9 anos", new Data(29, 11, 2025)));
        vacina.add(new Vacina("Vacina covid19", 0.75, "10 - 18 anos", new Data(29, 11, 2025)));
        vacina.add(new Vacina("Vacina covid19", 0.85, "Acima de 18 anos", new Data(29, 11, 2025)));
        vacina.add(new Vacina("vacina qualquer", 0.45, "0 - 2 anos", new Data(02, 07, 2027)));
        vacina.add(new Vacina("vacina qualquer", 0.55, "3  – 9 anos", new Data(02, 07, 2027)));
        vacina.add(new Vacina("vacina qualquer", 0.70, "10 - 18 anos", new Data(02, 07, 2027)));
        vacina.add(new Vacina("vacina qualquer", 0.95, "Acima de 18 anos", new Data(02, 07, 2027)));

    }
    
    public String bruscarnome(long sus){
      String nome = null;
    for( int i=0; i <paciente.length;i++){
    if (sus== paciente[i].getCartaoDoSus()){
    nome= paciente[i].getNome();
     }}
    return nome;
    }
 
    public static void main(String[] args) {
        Consulta consulta= new Consulta();
        consulta.simuladadosmedico();
        telas.TelaLogin tela = new TelaLogin();
        tela.setVisible(true);
    }
    
    public  void marcarconsultamedico( String nome, long sus){
    for(int i=0; i< paciente.length;i++){
    if(nome.equalsIgnoreCase(paciente[i].getNome())){
        if(sus==paciente[i].getCartaoDoSus()){
            TelaMarcarConsulta.paciente=paciente[i];
            TelaMarcarConsulta obj = new TelaMarcarConsulta();
            obj.setVisible(true);
        }}}}
  
    public int BuscarIdade(String nome, String sus){
    long temp= Long.valueOf(sus);
    int idade=0;
        for(int i=0; i< paciente.length; i++){
        if(paciente[i].getNome().equalsIgnoreCase(nome)){
        if(paciente[i].getCartaoDoSus()== temp){
        idade=paciente[i].getIdade();}}}
    return idade;}
    
    
    public double pegardose(String Vacina, int idade){
    double dose=0;
  
    
    for(int i = 0; i< vacina.size(); i++){
        
      if(Vacina.equalsIgnoreCase(vacina.get(i).getNome())){  
          
        if(vacina.get(i).getIndicacao().length()<=10){
          if(idade>=0 && idade<=2){dose=vacina.get(i).getDose();break; }}
        
        
        else if(vacina.get(i).getIndicacao().length()>10 &&vacina.get(i).getIndicacao().length()<12){
         if(idade>=3 && idade<=9){dose=vacina.get(i).getDose();break;}}
      
        
      else if(vacina.get(i).getIndicacao().length()>=12&& vacina.get(i).getIndicacao().length()<16){
      if(idade>=10 && idade<=18){dose=vacina.get(i).getDose();break;}}
     
      else if(vacina.get(i).getIndicacao().length()>=16 && vacina.get(i).getIndicacao().length()<20){
      if(idade>18){dose=vacina.get(i).getDose();break;}}
      } }
      
      
      return dose; 

  }
}
        
    
        
        