
package newpackage;


public class teste {

    
    
    public teste() {
        
    }

    public teste(int p, int m, int e) {
        this.p = p;
        this.m = m;
        this.e = e;
    }

   
    private int p,m,e;
    
    private int Atualizar(int n){
        switch (n) {
            case 0:
                p++; return p;
            case 1:
                m++;return m;
            case 2:
                e++;return e;
            default:
                break;
        }
return 0;}
    
    
    public static void main(String[] args) {
   teste obj= new teste();
   
        System.out.println(obj.Atualizar(0));
    
            
    }
}
